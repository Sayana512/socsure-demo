from datetime import datetime,timezone
from pathlib import Path
from threading import RLock
from typing import Literal
import csv, io, json, math
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from . import storage
from .analysis import analyze, normalize, review_pack, SCHEMA, DEFAULT_RULES
from .demo import generate_demo

app=FastAPI(docs_url=None,redoc_url=None,title='SOCSure',description='Offline supervisory decision support. Synthetic demonstration; not a SIEM.',version='1.0.0')
lock=RLock();storage.init();current=storage.latest()

def ensure():
    global current
    if current is None:
        raw=generate_demo();current=storage.save(raw,analyze(raw))
    return current

def decorated():
    result=ensure();events=storage.decisions(result['dataset_version']);decisions={x['finding_id']:x for x in events}
    ff=[{**f,**{k:decisions.get(f['finding_id'],{}).get(k,f[k]) for k in ('decision','notes')}} for f in result['findings']]
    return {**result,'findings':ff,'decision_events':events}

@app.get('/api/state')
def state():
    with lock:
        r=decorated();return {k:v for k,v in r.items() if k not in ('records','features')}

@app.post('/api/demo')
def demo():
    global current
    with lock:
        raw=generate_demo();current=storage.save(raw,analyze(raw));return {'version':current['dataset_version']}

@app.get('/api/demo/download')
def download_demo():return generate_demo()

@app.get('/api/schema')
def schema():return SCHEMA

@app.post('/api/upload')
async def upload(files:list[UploadFile]=File(...),mode:Literal['replace','merge']=Form('replace'),dataset:str=Form('')):
    global current
    incoming={};total=0
    try:
        for f in files:
            blob=await f.read(10*1024*1024+1);total+=len(blob)
            if total>10*1024*1024:raise ValueError('Upload limit is 10 MB per submission')
            name=f.filename or ''
            if name.lower().endswith('.json'):
                obj=json.loads(blob.decode('utf-8-sig'))
                if isinstance(obj,list):
                    if dataset not in SCHEMA:raise ValueError('Select a logical dataset for an array upload')
                    obj={dataset:obj}
                if not isinstance(obj,dict):raise ValueError('JSON must be a dataset object or array')
                for k,rows in normalize(obj).items():incoming.setdefault(k,[]).extend(rows)
            elif name.lower().endswith('.csv'):
                table=dataset or Path(name).stem.lower()
                if table not in SCHEMA:raise ValueError('Name CSV files entities/assets/alerts/cases/actions/escalations.csv or select a dataset')
                incoming.setdefault(table,[]).extend(list(csv.DictReader(io.StringIO(blob.decode('utf-8-sig')))))
            else:raise ValueError('Only CSV and JSON files are supported')
        if sum(len(v) for v in incoming.values())>50000:raise ValueError('Prototype limit: 50,000 total records')
        if not any(incoming.values()):raise ValueError('No recognized records found')
        with lock:
            raw=storage.raw(ensure()['dataset_version']) if mode=='merge' else {k:[] for k in SCHEMA}
            # Merge replaces supplied nonempty logical tables, preserving other tables.
            for k,v in incoming.items():
                if v:raw[k]=v
            if len(raw.get('cases',[]))>5000:raise ValueError('Prototype limit: 5,000 cases per analysis')
            result=analyze(raw,current['rules'] if current else None)
            current=storage.save(raw,result)
        return {'version':current['dataset_version'],'quality':current['quality']}
    except (ValueError,UnicodeError,KeyError,TypeError) as exc:raise HTTPException(422,str(exc))

class Rules(BaseModel):
    rapid_minutes:float=Field(10,gt=0,le=1440)
    low_actions:int=Field(2,ge=1,le=50)
    repeat_alerts:int=Field(4,ge=1,le=100)
    mass_count:int=Field(8,ge=2,le=5000)
    mass_window_minutes:float=Field(10,gt=0,le=1440)
    note_similarity:float=Field(.92,ge=.5,le=1)
    rare_workflow_share:float=Field(.02,gt=0,le=.5)
    coverage_drop_ratio:float=Field(.5,gt=0,lt=1)

@app.post('/api/analyze')
def run(rules:Rules):
    global current
    with lock:
        raw=storage.raw(ensure()['dataset_version']);current=storage.save(raw,analyze(raw,rules.model_dump()));return {'version':current['dataset_version']}

@app.get('/api/review')
def review(budget:int=20,period:str=''):
    if budget not in (10,20,50):raise HTTPException(422,'Budget must be 10, 20, or 50')
    with lock:
        r=decorated();ff=[f for f in r['findings'] if (not period or f['period']==period) and f['decision']=='Unreviewed' and f['finding_type']!='Peer baseline only']
        pack=review_pack(ff,budget)
        return {'selected':pack,'available':len(ff),'budget':budget,'selected_count':len(pack),'review_reduction':round(100*(1-len(pack)/len(ff)),1) if ff else 0}

class Decision(BaseModel):
    decision:Literal['Confirm','Dismiss','Needs more context']
    notes:str=Field('',max_length=4000)

@app.post('/api/findings/{fid}/decision')
def decide(fid:str,body:Decision):
    with lock:
        r=ensure()
        if not any(f['finding_id']==fid for f in r['findings']):raise HTTPException(404,'Finding not in current dataset')
        storage.decision(r,fid,body.decision,body.notes,datetime.now(timezone.utc).isoformat());return {'saved':True}

@app.get('/api/findings/{fid}/evidence')
def evidence(fid:str):
    with lock:
        r=decorated();f=next((f for f in r['findings'] if f['finding_id']==fid),None)
        if not f:raise HTTPException(404,'Finding not found')
        rec=r['records'];cid=f['case_id'];aids=set(f['input_record_ids'])
        return {'finding':f,'cases':[x for x in rec['cases'] if x['case_id']==cid],'alerts':[x for x in rec['alerts'] if x['alert_id'] in aids],'assets':[x for x in rec['assets'] if x['asset_id']==f['asset_id'] or (not cid and x['entity_id']==f['entity_id'])],'actions':[x for x in rec['actions'] if x['case_id']==cid],'escalations':[x for x in rec['escalations'] if x['case_id']==cid]}

@app.get('/api/audit/export')
def audit_export():
    with lock:
        r=decorated();return {'run_id':r['run_id'],'dataset_version':r['dataset_version'],'analysis_timestamp':r['analysis_timestamp'],'rules':r['rules'],'model':r['model'],'findings':r['findings'],'decisions':r['decision_events']}

@app.get('/api/health')
def health():return {'status':'ok','mode':'local'}

DIST=Path(__file__).resolve().parents[1]/'frontend'/'dist'
if DIST.exists():
    app.mount('/assets',StaticFiles(directory=DIST/'assets'),name='assets')
    @app.get('/')
    def index():return FileResponse(DIST/'index.html')
    @app.get('/favicon.svg')
    def icon():return FileResponse(DIST/'favicon.svg')
