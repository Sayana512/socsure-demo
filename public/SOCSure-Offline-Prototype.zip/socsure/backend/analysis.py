"""Offline supervisory analysis. Signals are review leads, never determinations."""
import hashlib, json, re
from functools import lru_cache
from collections import Counter, defaultdict
from datetime import datetime, timezone
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.preprocessing import StandardScaler

SCHEMA = {
 'entities':['entity_id','entity_name','sector','reporting_period'],
 'assets':['asset_id','entity_id','asset_type','criticality'],
 'alerts':['alert_id','entity_id','asset_id','timestamp','severity','alert_type'],
 'cases':['case_id','alert_id','entity_id','created_at','closed_at','initial_severity','final_severity','status','disposition','analyst_id'],
 'actions':['action_id','case_id','timestamp','action_type','investigation_note'],
 'escalations':['escalation_id','case_id','timestamp','escalation_level']}
IDS={'entities':['entity_id','reporting_period'],'assets':['asset_id'],'alerts':['alert_id'],'cases':['case_id'],'actions':['action_id'],'escalations':['escalation_id']}
DEFAULT_RULES={'rapid_minutes':10,'low_actions':2,'repeat_alerts':4,'mass_count':8,'mass_window_minutes':10,'note_similarity':.92,'rare_workflow_share':.02,'coverage_drop_ratio':.5}
SEVERITY={'Low':1,'Medium':2,'High':3,'Critical':4}
DIMENSIONS=['Detection','Investigation','Escalation','Operational Discipline','Monitoring Coverage','Evidence Quality']
METRICS=['escalation_rate','investigation_depth','case_duration','critical_alert_ratio','repeat_alert_rate','rapid_closure_rate','asset_coverage','critical_asset_coverage','severity_downgrade_rate','mass_closure_rate','repetitive_note_rate']
ALIASES={'cse_id':'entity_id','cse_name':'entity_name','period':'reporting_period','investigation_actions':'actions','cse':'entities','entity':'entities'}

def canonical(key):
    key=re.sub(r'(?<=[a-z0-9])(?=[A-Z])','_',str(key)).lower().strip().replace(' ','_').replace('-','_')
    return ALIASES.get(key,key)

def normalize(raw):
    out={k:[] for k in SCHEMA}
    for name, rows in raw.items():
        name=canonical(name)
        if name not in SCHEMA: continue
        if not isinstance(rows,list) or any(not isinstance(r,dict) for r in rows):
            raise ValueError(f'{name} must be an array of objects')
        for r in rows:
            r={canonical(k):v for k,v in r.items()}
            for k,v in list(r.items()):
                if isinstance(v,(dict,list)): raise ValueError(f'{name}.{k} must be a scalar value')
                if isinstance(v,str): r[k]=v.strip()
                if k in ['severity','criticality','initial_severity','final_severity','status','action_type'] and isinstance(v,str): r[k]=v.strip().title()
            out[name].append(r)
    return out

@lru_cache(maxsize=100000)
def stamp(value):
    return pd.to_datetime(value,errors='coerce',utc=True)

def quality(raw):
    issues=[]; missing=0; slots=0; dup=0; invalid=0; broken=0
    frames={}
    def issue(table,r,kind,detail):
        issues.append({'table':table,'record_id':str(r.get(IDS[table][0],'')),'entity_id':str(r.get('entity_id','')),'kind':kind,'detail':detail})
    for table,fields in SCHEMA.items():
        seen=set(); clean=[]
        for r in raw[table]:
            optional={'closed_at'} if table=='cases' and r.get('status')!='Closed' else set()
            for f in fields:
                if f in optional: continue
                slots+=1
                if r.get(f) is None or str(r.get(f)).strip()=='': missing+=1;issue(table,r,'Missing value',f)
            key=tuple(str(r.get(k,'')) for k in IDS[table])
            if key in seen: dup+=1;issue(table,r,'Duplicate',' / '.join(key)); continue
            seen.add(key)
            for field in ['timestamp','created_at','closed_at']:
                if r.get(field) and pd.isna(stamp(r[field])): invalid+=1;issue(table,r,'Invalid timestamp',field)
            if table=='entities' and not re.fullmatch(r'\d{4}-(0[1-9]|1[0-2])',str(r.get('reporting_period',''))):
                issue(table,r,'Missing reporting period','Expected YYYY-MM')
            clean.append(r)
        frames[table]=pd.DataFrame(clean,columns=fields).fillna('')
        if not raw[table] and table!='escalations': issue(table,{},'Missing dataset',table)
    maps={t:{str(r.get(IDS[t][0],'')):r for r in raw[t]} for t in SCHEMA}
    for table,field,target in [('assets','entity_id','entities'),('alerts','entity_id','entities'),('alerts','asset_id','assets'),('cases','alert_id','alerts'),('cases','entity_id','entities'),('actions','case_id','cases'),('escalations','case_id','cases')]:
        for r in raw[table]:
            other=maps[target].get(str(r.get(field,'')))
            if other is None:
                broken+=1;issue(table,r,'Broken link',f'{field} → {target}')
            elif r.get('entity_id') and other.get('entity_id') and r['entity_id']!=other['entity_id']:
                broken+=1;issue(table,r,'Broken link',f'{field} crosses entities')
    action_cases=set(frames['actions'].case_id)
    declared={(r.get('entity_id'),r.get('reporting_period')) for r in raw['entities']}
    for r in raw['cases']:
        if r.get('case_id') not in action_cases: issue('cases',r,'Incomplete investigation evidence','No submitted investigation actions')
        start,end=stamp(r.get('created_at')),stamp(r.get('closed_at'))
        if not pd.isna(start) and not pd.isna(end) and end<start: invalid+=1;issue('cases',r,'Invalid timestamp','Closure precedes creation')
        if not pd.isna(start) and (r.get('entity_id'),start.strftime('%Y-%m')) not in declared: issue('cases',r,'Missing reporting period',start.strftime('%Y-%m'))
    completeness=round(100*(1-missing/max(slots,1)),1) if slots else 0
    conf='High' if completeness>=98 and not issues else ('Medium' if completeness>=90 and broken+invalid<max(5,len(raw['cases'])*.05) else 'Low')
    if any(i['kind']=='Missing dataset' for i in issues): conf='Low'
    q={'completeness':completeness,'duplicate_count':dup,'broken_link_count':broken,'missing_value_count':missing,'invalid_timestamp_count':invalid,'confidence':conf,'issues':issues}
    return frames,q

def review_pack(findings,budget=20):
    # Round-robin across type AND entity, deduplicating cases across finding types.
    groups=defaultdict(list)
    for f in sorted(findings,key=lambda x:-x['priority_score']): groups[(f['finding_type'],f['entity_id'])].append(f)
    keys=sorted(groups,key=lambda k:-groups[k][0]['priority_score']); selected=[];used=set()
    while len(selected)<budget and any(groups.values()):
        for k in keys:
            while groups[k]:
                f=groups[k].pop(0); identity=f['case_id'] or f"{f['entity_id']}:{f['period']}:{f['finding_type']}"
                if identity not in used:
                    used.add(identity);selected.append({**f,'selection_reason':f'Highest remaining priority in {k[0]} for {f["entity_name"]}; adds category/entity coverage.'});break
            if len(selected)>=budget:break
    return selected

def analyze(raw,rules=None):
    rules={**DEFAULT_RULES,**(rules or {})};raw=normalize(raw);df,q=quality(raw)
    version=hashlib.sha256(json.dumps(raw,sort_keys=True).encode()).hexdigest()[:12]
    now=datetime.now(timezone.utc).isoformat()
    records={t:frame.to_dict('records') for t,frame in df.items()}
    names={r['entity_id']:r for r in records['entities']}
    alerts={r['alert_id']:r for r in records['alerts']}
    asset_map={r['asset_id']:r for r in records['assets']}
    actions=defaultdict(list);esc=defaultdict(list)
    for r in records['actions']:actions[r['case_id']].append(r)
    for r in records['escalations']:esc[r['case_id']].append(r)
    feats=[]
    # Previous alerts are strictly earlier and match asset and alert type.
    alert_history=defaultdict(list)
    for a in records['alerts']:
        t=stamp(a['timestamp'])
        if not pd.isna(t):alert_history[(a['asset_id'],a['alert_type'])].append(t)
    for c in records['cases']:
        created,closed=stamp(c['created_at']),stamp(c['closed_at'])
        if pd.isna(created) or not c['case_id'] or c['entity_id'] not in names:continue
        aa=sorted(actions[c['case_id']],key=lambda a:str(a['timestamp']))
        usable=[a for a in aa if not pd.isna(stamp(a['timestamp']))]
        a=alerts.get(c['alert_id'],{})
        dur=(closed-created).total_seconds()/60 if not pd.isna(closed) and closed>=created else None
        workflow=['Alert']+[x['action_type'] for x in usable]
        events=[(stamp(x['timestamp']),x['action_type']) for x in usable]+[(stamp(x['timestamp']),'Escalate') for x in esc[c['case_id']] if not pd.isna(stamp(x['timestamp']))]
        workflow=['Alert']+[kind for _,kind in sorted(events,key=lambda x:x[0])]+(['Close'] if c['status']=='Closed' and dur is not None else [])
        feats.append({**c,'period':created.strftime('%Y-%m'),'asset_id':a.get('asset_id',''),'duration':dur,'depth':sum(x['action_type'] not in ('Assign','Close') for x in usable),'action_count':len(usable),'escalation_count':len(esc[c['case_id']]),'reopen_count':sum(x['action_type']=='Reopen' for x in usable),'asset_severity_num':SEVERITY.get(asset_map.get(a.get('asset_id'),{}).get('criticality'),2),'severity_num':SEVERITY.get(c['initial_severity'],2),'downgrade':int(SEVERITY.get(c['initial_severity'],2)>SEVERITY.get(c['final_severity'],2)),'previous_alerts':sum(t<created-timedelta_minutes(2) for t in alert_history[(a.get('asset_id',''),a.get('alert_type',''))]),'note':' '.join(x['investigation_note'] for x in usable),'note_similarity':0.,'workflow':' → '.join(workflow),'mass_count':0})
    # Bounded blocks prevent an O(n²) resident matrix. No cross-case self similarity.
    texts=[x['note'] for x in feats]
    if sum(bool(t.strip()) for t in texts)>1:
        try:
            tf=TfidfVectorizer(min_df=1,token_pattern=r'(?u)\b\w+\b').fit_transform(texts)
            for start in range(0,len(feats),128):
                sim=cosine_similarity(tf[start:start+128],tf)
                for j,row in enumerate(sim):
                    i=start+j;row[i]=0
                    # Only compare different assets: unrelated case proxy.
                    for k,f in enumerate(feats):
                        if f['asset_id']==feats[i]['asset_id']:row[k]=0
                    feats[i]['note_similarity']=round(float(row.max()),4)
        except ValueError:pass
    closure_groups=defaultdict(list)
    for f in feats:
        end=stamp(f['closed_at'])
        if not pd.isna(end):closure_groups[(f['entity_id'],f['period'])].append(end.timestamp())
    for key in closure_groups:closure_groups[key]=np.sort(closure_groups[key])
    for f in feats:
        end=stamp(f['closed_at'])
        if not pd.isna(end):
            values=closure_groups[(f['entity_id'],f['period'])];t=end.timestamp();w=rules['mass_window_minutes']*60
            f['mass_count']=int(np.searchsorted(values,t+w,side='right')-np.searchsorted(values,t-w,side='left'))
    numeric=['duration','depth','escalation_count','reopen_count','severity_num','downgrade','previous_alerts','note_similarity','mass_count']
    if len(feats)>=20:
        X=pd.DataFrame(feats)[numeric].replace([np.inf,-np.inf],np.nan).fillna(0)
        model=IsolationForest(n_estimators=100,contamination=.1,random_state=26157,n_jobs=1).fit(X)
        scores=-model.score_samples(X);threshold=float(np.quantile(scores,.9))
        med=X.median();mad=(X-med).abs().median().replace(0,1)
        for i,f in enumerate(feats):
            f['anomaly_score']=round(float(scores[i]),4);f['is_anomaly']=bool(scores[i]>=threshold)
            z=((X.iloc[i]-med)/mad).abs().sort_values(ascending=False)
            f['unusual_features']=[{'feature':k,'value':float(X.iloc[i][k]),'cohort_median':float(med[k])} for k in z.index[:3]]
    else:
        for f in feats:f.update(anomaly_score=0.,is_anomaly=False,unusual_features=[])
    profiles=[]
    periods=sorted(set(r['reporting_period'] for r in records['entities'] if re.fullmatch(r'\d{4}-\d{2}',r['reporting_period'])))
    for eid in names:
        assets=[a for a in records['assets'] if a['entity_id']==eid];critical={a['asset_id'] for a in assets if a['criticality']=='Critical'}
        declared_periods=sorted({r['reporting_period'] for r in records['entities'] if r['entity_id']==eid})
        for p in declared_periods:
            ff=[f for f in feats if f['entity_id']==eid and f['period']==p]
            aa=[a for a in records['alerts'] if a['entity_id']==eid and not pd.isna(stamp(a['timestamp'])) and stamp(a['timestamp']).strftime('%Y-%m')==p]
            n=max(len(ff),1);high=[f for f in ff if f['severity_num']>=3];seen={a['asset_id'] for a in aa}
            dur=[f['duration'] for f in ff if f['duration'] is not None]
            profiles.append({'entity_id':eid,'entity_name':names[eid]['entity_name'],'sector':names[eid]['sector'],'period':p,'cases':len(ff),'alerts':len(aa),'assets':len(assets),'escalation_rate':sum(f['escalation_count']>0 for f in high)/len(high) if high else None,'investigation_depth':float(np.median([f['depth'] for f in ff])) if ff else None,'case_duration':float(np.median(dur)) if dur else None,'critical_alert_ratio':sum(a['severity']=='Critical' for a in aa)/len(aa) if aa else None,'repeat_alert_rate':sum(f['previous_alerts']>=rules['repeat_alerts'] for f in ff)/n,'rapid_closure_rate':sum(f['duration'] is not None and f['duration']<rules['rapid_minutes'] for f in ff)/n,'asset_coverage':len(seen & {a['asset_id'] for a in assets})/len(assets) if assets else None,'critical_asset_coverage':len(seen & critical)/len(critical) if critical else None,'severity_downgrade_rate':sum(f['downgrade'] for f in ff)/n,'mass_closure_rate':sum(f['mass_count']>=rules['mass_count'] for f in ff)/n,'repetitive_note_rate':sum(f['note_similarity']>=rules['note_similarity'] for f in ff)/n})
    def median(rows,m):
        vals=[r[m] for r in rows if r.get(m) is not None]
        return round(float(np.median(vals)),4) if vals else None
    for p in profiles:
        hist=[x for x in profiles if x['entity_id']==p['entity_id'] and x['period']<p['period']]
        candidates=[x for x in profiles if x['entity_id']!=p['entity_id'] and x['period']==p['period']]
        # Structural peer matching avoids selecting peers on the very weakness under review.
        def distance(x):
            return (0 if x['sector']==p['sector'] else 2)+abs(np.log1p(x['assets'])-np.log1p(p['assets']))+abs(np.log1p(x['alerts'])-np.log1p(p['alerts']))+abs((x['critical_alert_ratio'] or 0)-(p['critical_alert_ratio'] or 0))
        peers=sorted(candidates,key=distance)[:3]
        p['peer_ids']=[x['entity_id'] for x in peers];p['history_periods']=len(hist)
        p['baseline']={m:{'current':p[m],'historical':median(hist,m),'peer':median(peers,m)} for m in METRICS}
        for m,b in p['baseline'].items():
            base=b['historical'] if b['historical'] is not None else b['peer']
            b['deviation']=round(b['current']-base,4) if base is not None and b['current'] is not None else None
    profile_map={(p['entity_id'],p['period']):p for p in profiles}
    variants=Counter(f['workflow'] for f in feats);findings=[]
    def add(eid,period,kind,dimension,signals,features,case=None,metric=None,explanation=''):
        p=profile_map.get((eid,period))
        if not p:return
        data_conf=q['confidence'];families=sorted({s['detector'] for s in signals})
        supervision='High' if len(families)>=3 and data_conf=='High' else ('Medium' if len(families)>=2 and data_conf!='Low' else 'Low')
        baseline=p['baseline'].get(metric,{})
        severity=max(case['severity_num'],case.get('asset_severity_num',1))/4 if case else .75
        strength=max((case or {}).get('anomaly_score',0), min(len(signals)/6,1))
        history=int(any(s['detector']=='History' for s in signals));peer=int(any(s['detector']=='Peers' for s in signals))
        repetition=min(((case or {}).get('previous_alerts',0)+(case or {}).get('mass_count',0))/15,1)
        score=round(100*(.2*severity+.2*strength+.2*min(len(signals)/6,1)+.1*repetition+.1*history+.1*peer+.1*{'High':1,'Medium':.6,'Low':.2}[data_conf]))
        fid='F-'+hashlib.sha256(f'{version}:{eid}:{period}:{kind}:{(case or {}).get("case_id","")}'.encode()).hexdigest()[:10]
        findings.append({'finding_id':fid,'entity_id':eid,'entity_name':p['entity_name'],'period':period,'finding_type':kind,'dimension':dimension,'case_id':(case or {}).get('case_id',''),'asset_id':(case or {}).get('asset_id',''),'alert_id':(case or {}).get('alert_id',''),'severity':(case or {}).get('initial_severity','High'),'explanation':explanation,'signals':signals,'detectors':families,'feature_values':features,'baseline_metric':metric,'baseline':baseline,'peer_ids':p['peer_ids'],'data_confidence':data_conf,'supervisory_confidence':supervision,'priority_score':score,'priority':'High' if score>=65 else ('Medium' if score>=40 else 'Low'),'anomaly_score':(case or {}).get('anomaly_score',0),'anomaly_level':'Unusual' if (case or {}).get('is_anomaly') else 'Not flagged / not applicable','unusual_features':(case or {}).get('unusual_features',[]),'dataset_version':version,'analysis_timestamp':now,'input_record_ids':([case['case_id'],case['alert_id']]+[a['action_id'] for a in actions[case['case_id']]]+[a['escalation_id'] for a in esc[case['case_id']]]) if case else [a['alert_id'] for a in records['alerts'] if a['entity_id']==eid and str(a['timestamp']).startswith(period)],'decision':'Unreviewed','notes':''})
    def context(p,metric,low=False):
        out=[]; b=p['baseline'][metric];current=b['current']
        if current is None:return out
        for key,detector in [('historical','History'),('peer','Peers')]:
            base=b[key]
            if base is not None and ((low and current<base*(rules['coverage_drop_ratio'] if metric.endswith('coverage') else .65)) or (not low and current>max(base*1.5,base+.1))):
                out.append({'detector':detector,'label':f'{metric.replace("_"," ")}: {current:.3f} versus {base:.3f}'})
        return out
    for f in feats:
        p=profile_map.get((f['entity_id'],f['period']))
        if not p:continue
        signals=[];types=[]
        def hit(condition,label,kind,dim,metric):
            if condition:signals.append({'detector':'Rules','label':label});types.append((kind,dim,metric))
        hit(f['severity_num']>=3 and f['escalation_count']==0,'High/Critical case has no submitted escalation','Escalation anomaly','Escalation','escalation_rate')
        hit(f['severity_num']>=3 and f['depth']<rules['low_actions'],'Low investigation activity on severe case','Weak investigation','Investigation','investigation_depth')
        hit(f['duration'] is not None and f['duration']<rules['rapid_minutes'],'Case closed unusually quickly','Rapid closure','Operational Discipline','rapid_closure_rate')
        hit(f['previous_alerts']>=rules['repeat_alerts'],'Repeated alerts of the same type on this asset','Repeated-asset pattern','Detection','repeat_alert_rate')
        hit(f['mass_count']>=rules['mass_count'],'Cluster of closures within the configured time window','Mass closure','Operational Discipline','mass_closure_rate')
        hit(f['downgrade'] and p['severity_downgrade_rate']>.1,'Repeated severity downgrade pattern','Severity downgrade','Operational Discipline','severity_downgrade_rate')
        hit(f['reopen_count'] and f['duration'] is not None and f['duration']<rules['rapid_minutes'],'Rapid handling with a recorded reopen action','Rapid closure / reopen','Operational Discipline','rapid_closure_rate')
        if f['is_anomaly']:signals.append({'detector':'Isolation Forest','label':'Unusual numerical feature combination; cohort-relative score'});types.append(('Unusual combination','Investigation','investigation_depth'))
        if variants[f['workflow']]/max(len(feats),1)<rules['rare_workflow_share']:
            signals.append({'detector':'Workflow','label':'Rare workflow variant — review recommended'});types.append(('Rare workflow','Operational Discipline','investigation_depth'))
        if f['note_similarity']>=rules['note_similarity']:
            signals.append({'detector':'Text','label':f'Notes resemble a case on a different asset (cosine {f["note_similarity"]:.2f})'});types.append(('Repetitive notes','Investigation','repetitive_note_rate'))
        if not signals:continue
        # One case finding with all independent supporting families; primary type favors specificity.
        preference=['Rapid closure / reopen','Severity downgrade','Mass closure','Repetitive notes','Weak investigation','Rapid closure','Escalation anomaly','Repeated-asset pattern','Rare workflow','Unusual combination']
        kind,dim,metric=min(types,key=lambda t:preference.index(t[0]))
        signals+=context(p,metric,metric in ('escalation_rate','investigation_depth'))
        add(f['entity_id'],f['period'],kind,dim,signals,{k:f[k] for k in numeric+['workflow']},f,metric,f'{f["case_id"]} shows {kind.lower()}. Review the submitted records and operational context before drawing a conclusion.')
    for p in profiles:
        for metric,kind,dim in [('escalation_rate','Escalation rate drop','Escalation'),('investigation_depth','Investigation activity drop','Investigation'),('asset_coverage','Potential monitoring gap','Monitoring Coverage'),('critical_asset_coverage','Critical asset activity drop','Monitoring Coverage')]:
            signals=context(p,metric,True)
            if not signals:continue
            if metric.endswith('coverage'):signals.append({'detector':'Negative space','label':'Unusually low submitted asset activity; inactive assets are not proof of a monitoring failure'})
            else:signals.append({'detector':'Aggregate','label':'Reduced operational activity in the reporting period'})
            if q['confidence']!='High':signals.append({'detector':'Evidence quality','label':'Incomplete submitted evidence reduces confidence; request clarification'})
            add(p['entity_id'],p['period'],kind,dim,signals,{metric:p[metric]},metric=metric,explanation='Activity is lower than available baselines. '+('Incomplete submitted evidence may explain this pattern.' if q['confidence']!='High' else 'Review recommended; verify the expected scope of monitoring and operational context.'))
    for p in profiles:
        if p['history_periods']==0:
            add(p['entity_id'],p['period'],'Peer baseline only','Evidence Quality',[{'detector':'Context','label':'No earlier submission; first period is not a normal historical baseline'}],{'history_periods':0},metric='escalation_rate',explanation='A temporary matched-peer baseline is used because no earlier reporting period is available.')
    findings.sort(key=lambda f:-f['priority_score'])
    for i,f in enumerate(findings):f['rank']=i+1
    latest=max(periods,default='')
    entities=[]
    for eid in names:
        pp=[p for p in profiles if p['entity_id']==eid]
        if not pp:continue
        p=max(pp,key=lambda x:x['period']);ff=[f for f in findings if f['entity_id']==eid and f['period']==p['period']]
        dims={d:('High' if any(f['priority']=='High' and f['dimension']==d for f in ff) else ('Medium' if any(f['dimension']==d for f in ff) else 'Low')) for d in DIMENSIONS}
        dims['Evidence Quality']={'High':'Low','Medium':'Medium','Low':'High'}[q['confidence']]
        entities.append({**p,'dimensions':dims,'finding_count':len(ff),'data_confidence':q['confidence'],'attention':'High' if 'High' in dims.values() else ('Medium' if 'Medium' in dims.values() else 'Low')})
    return {'dataset_version':version,'analysis_timestamp':now,'rules':rules,'quality':q,'counts':{k:len(v) for k,v in records.items()},'periods':periods,'latest_period':latest,'entities':entities,'profiles':profiles,'findings':findings,'workflows':[{'variant':v,'count':n,'share':n/max(len(feats),1)} for v,n in variants.most_common()],'records':records,'features':feats,'model':{'algorithm':'Isolation Forest','training_scope':'All valid submitted cases; exploratory cohort-relative model, not a normal historical model','minimum_cases':20,'fitted':len(feats)>=20,'seed':26157,'contamination':.1,'explanation':'Unusual feature values are robust median deviations, not causal model attributions.'}}

def timedelta_minutes(n):
    return pd.Timedelta(minutes=n)
