"""Deterministic synthetic evidence. All organizations and people are fictional."""
import random
from datetime import datetime, timedelta, timezone


def generate_demo(seed=26157):
    rng = random.Random(seed)
    data = {k: [] for k in ('entities', 'assets', 'alerts', 'cases', 'actions', 'escalations')}
    names = [('Northern Grid','Energy'), ('Western Power','Energy'), ('Coastal Bank','Finance'), ('National Payments','Finance'), ('Metro Telecom','Telecom'), ('Eastern Network','Telecom'), ('River Utilities','Energy')]
    periods = ['2026-04', '2026-05', '2026-06']
    iso = lambda d: d.isoformat()
    for e, (name, sector) in enumerate(names):
        eid = f'CSE-{e+1:02}'
        for p in periods if e < 6 else periods[-1:]:
            data['entities'].append(dict(entity_id=eid, entity_name=name, sector=sector, reporting_period=p))
        for a in range(30):
            data['assets'].append(dict(asset_id=f'{eid}-A{a+1:03}', entity_id=eid, asset_type=['Server','Endpoint','Gateway'][a%3], criticality='Critical' if a < 10 else 'Medium'))
        for p in periods if e < 6 else periods[-1:]:
            base = datetime.fromisoformat(p+'-01').replace(tzinfo=timezone.utc)
            for n in range(60):
                key=f'{e+1:02}-{p[5:]}-{n+1:03}'
                cid, aid=f'CAS-{key}', f'ALT-{key}'
                current=p==periods[-1]
                a = n%24 if n<24 else rng.randrange(24)
                if current and e==5: a=10+n%2
                if current and e==3 and n<20: a=2
                created=base+timedelta(days=n//3, hours=(n%3)*6, minutes=rng.randrange(30))
                severe=n%2==0
                sev='Critical' if n%4==0 else ('High' if severe else 'Medium')
                duration=rng.uniform(90,650)
                depth=rng.randint(3,7)
                escalation=severe and (n%4==0)
                if current and e==0: escalation=severe and n in (0,2)
                if current and e==2 and n<14: duration=3; depth=1; escalation=False
                if current and e==3 and n<20: duration=5; depth=2
                closed=created+timedelta(minutes=duration)
                if current and e==4 and n<18: closed=base+timedelta(days=20, hours=12, seconds=n*5)
                final='Low' if current and e==4 and n<24 and severe else sev
                data['alerts'].append(dict(alert_id=aid, entity_id=eid, asset_id=f'{eid}-A{a+1:03}', timestamp=iso(created-timedelta(minutes=2)), severity=sev, alert_type='Repeated authentication failures' if e==3 and n<20 else ['Access anomaly','Malware alert','Configuration change'][n%3]))
                data['cases'].append(dict(case_id=cid, alert_id=aid, entity_id=eid, created_at=iso(created), closed_at=iso(closed), initial_severity=sev, final_severity=final, status='Closed', disposition='Resolved', analyst_id=f'AN-{e+1}-{n%5+1}'))
                for k in range(depth):
                    note=f'Examined {aid} on asset {a+1}; checked evidence item {rng.randrange(100000,999999)} and recorded response step {k+1}.'
                    if current and e==1 and n<28: note='Reviewed alert. No malicious activity observed. Closing after standard checks.'
                    kind='Investigate' if depth==1 or k>0 else 'Assign'
                    if current and e==2 and n in (0,1) and k==0: kind='Reopen'
                    data['actions'].append(dict(action_id=f'ACT-{key}-{k}',case_id=cid,timestamp=iso(created+(closed-created)*(k+1)/(depth+1)),action_type=kind,investigation_note=note))
                if escalation:
                    data['escalations'].append(dict(escalation_id=f'ESC-{key}',case_id=cid,timestamp=iso(created+(closed-created)*.7),escalation_level='L2'))
    return data

if __name__=='__main__':
    import json
    from pathlib import Path
    Path('data').mkdir(exist_ok=True)
    Path('data/demo.json').write_text(json.dumps(generate_demo(),indent=2))
