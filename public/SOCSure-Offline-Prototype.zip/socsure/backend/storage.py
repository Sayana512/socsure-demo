"""SQLite repository; API/analysis are independent of the persistence engine."""
import json, os, sqlite3
from contextlib import contextmanager
from pathlib import Path

DB=Path(os.environ.get('SOCSURE_DB',str(Path(__file__).resolve().parents[1]/'data'/'socsure.db')))
@contextmanager
def connection():
    DB.parent.mkdir(parents=True,exist_ok=True)
    conn=sqlite3.connect(DB,timeout=30);conn.row_factory=sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:conn.close()

def init():
    with connection() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS datasets(version TEXT PRIMARY KEY, raw TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS analyses(run_id INTEGER PRIMARY KEY AUTOINCREMENT, version TEXT NOT NULL, timestamp TEXT NOT NULL, result TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS decisions(event_id INTEGER PRIMARY KEY AUTOINCREMENT, finding_id TEXT NOT NULL, version TEXT NOT NULL, run_id INTEGER NOT NULL, timestamp TEXT NOT NULL, decision TEXT NOT NULL, notes TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_decisions_version_finding ON decisions(version,finding_id);
        ''')

def save(raw,result):
    with connection() as c:
        c.execute('INSERT OR IGNORE INTO datasets VALUES (?,?)',(result['dataset_version'],json.dumps(raw)))
        run=c.execute('INSERT INTO analyses(version,timestamp,result) VALUES (?,?,?)',(result['dataset_version'],result['analysis_timestamp'],json.dumps(result))).lastrowid
    result['run_id']=run
    return result

def latest():
    with connection() as c:
        row=c.execute('SELECT * FROM analyses ORDER BY run_id DESC LIMIT 1').fetchone()
    if not row:return None
    result=json.loads(row['result']);result['run_id']=row['run_id'];return result

def raw(version):
    with connection() as c:return json.loads(c.execute('SELECT raw FROM datasets WHERE version=?',(version,)).fetchone()['raw'])

def decisions(version):
    with connection() as c:return [dict(r) for r in c.execute('SELECT * FROM decisions WHERE version=? ORDER BY event_id',(version,))]

def decision(result,fid,value,notes,now):
    with connection() as c:c.execute('INSERT INTO decisions(finding_id,version,run_id,timestamp,decision,notes) VALUES (?,?,?,?,?,?)',(fid,result['dataset_version'],result['run_id'],now,value,notes))
