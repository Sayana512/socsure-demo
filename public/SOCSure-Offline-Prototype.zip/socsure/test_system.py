"""Integration checks use disposable SQLite storage."""
import os,tempfile,json,unittest
from pathlib import Path
TEMP=tempfile.TemporaryDirectory()
os.environ['SOCSURE_DB']=str(Path(TEMP.name)/'test.db')
from fastapi.testclient import TestClient
from backend.main import app
from backend.analysis import quality,normalize
from backend.demo import generate_demo
class SystemTest(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.client=TestClient(app)
  response=cls.client.get('/api/state');assert response.status_code==200,response.text
  cls.state=response.json()
 def test_scenarios_and_baselines(self):
  s=self.state;self.assertEqual(s['quality']['confidence'],'High');self.assertEqual(len(s['entities']),7)
  kinds={f['finding_type'] for f in s['findings'] if f['period']=='2026-06'}
  for kind in ['Escalation rate drop','Repetitive notes','Weak investigation','Repeated-asset pattern','Mass closure','Severity downgrade','Critical asset activity drop','Peer baseline only']:self.assertIn(kind,kinds)
  p=next(p for p in s['profiles'] if p['entity_id']=='CSE-01' and p['period']=='2026-06')
  self.assertAlmostEqual(p['escalation_rate'],2/30);self.assertEqual(p['baseline']['escalation_rate']['historical'],.5)
  new=next(p for p in s['profiles'] if p['entity_id']=='CSE-07');self.assertIsNone(new['baseline']['escalation_rate']['historical']);self.assertTrue(new['peer_ids'])
  self.assertTrue(all(len(f['detectors'])>=3 and f['data_confidence']=='High' for f in s['findings'] if f['supervisory_confidence']=='High'))
 def test_review_diversity_and_budget(self):
  pack=self.client.get('/api/review?budget=20&period=2026-06').json()['selected']
  self.assertEqual(len(pack),20);self.assertGreaterEqual(len({f['finding_type'] for f in pack}),8)
  cases=[f['case_id'] for f in pack if f['case_id']];self.assertEqual(len(cases),len(set(cases)))
  self.assertEqual(self.client.get('/api/review?budget=999').status_code,422)
 def test_decision_evidence_audit(self):
  f=self.state['findings'][0];fid=f['finding_id']
  evidence=self.client.get(f'/api/findings/{fid}/evidence').json();self.assertEqual(evidence['cases'][0]['case_id'],f['case_id'])
  response=self.client.post(f'/api/findings/{fid}/decision',json={'decision':'Confirm','notes':'Integration test review'});self.assertEqual(response.status_code,200)
  self.client.post(f'/api/findings/{fid}/decision',json={'decision':'Needs more context','notes':'Second event'})
  audit=self.client.get('/api/audit/export').json();self.assertEqual(len(audit['decisions']),2)
  self.assertEqual(audit['decisions'][0]['notes'],'Integration test review')
  self.assertEqual(next(x for x in audit['findings'] if x['finding_id']==fid)['decision'],'Needs more context')
  from backend import storage
  self.assertEqual(len(storage.decisions(f['dataset_version'])),2);self.assertIsNotNone(storage.latest())
 def test_quality_and_malformed_upload(self):
  raw=generate_demo();raw['cases'][0]['alert_id']='missing';raw['cases'][1]['created_at']='invalid';raw['assets'][0]['criticality']='';raw['alerts'].append(raw['alerts'][0])
  _,q=quality(normalize(raw));self.assertGreater(q['broken_link_count'],0);self.assertGreater(q['invalid_timestamp_count'],0);self.assertGreater(q['missing_value_count'],0);self.assertEqual(q['duplicate_count'],1);self.assertNotEqual(q['confidence'],'High')
  before=self.client.get('/api/state').json()['dataset_version']
  bad=self.client.post('/api/upload',files={'files':('bad.json',b'{not-json','application/json')});self.assertEqual(bad.status_code,422)
  self.assertEqual(before,self.client.get('/api/state').json()['dataset_version'])
 def test_z_csv_and_json_upload(self):
  r=self.client.post('/api/upload',files={'files':('entities.csv',b'entity_id,entity_name,sector,reporting_period\nTEST,Test SOC,Energy,2026-07\n','text/csv')},data={'mode':'replace'})
  self.assertEqual(r.status_code,200,r.text);s=self.client.get('/api/state').json();self.assertEqual(s['entities'][0]['entity_id'],'TEST');self.assertEqual(s['quality']['confidence'],'Low')
  r=self.client.post('/api/upload',files={'files':('demo.json',json.dumps(generate_demo()).encode(),'application/json')});self.assertEqual(r.status_code,200,r.text)
  self.assertEqual(self.client.get('/api/state').json()['counts']['cases'],1140)
if __name__=='__main__':unittest.main(verbosity=2)
