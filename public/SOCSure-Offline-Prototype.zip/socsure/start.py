"""One-command startup after dependency installation. No network requests."""
import os, sys
from pathlib import Path
root=Path(__file__).resolve().parent
os.chdir(root)
if not (root/'frontend'/'dist'/'index.html').exists():
    sys.exit('Frontend bundle missing. Run: cd frontend && npm ci && npm run build')
try:
    import uvicorn
except ImportError:
    sys.exit('Install dependencies first: python -m pip install -r requirements.txt')
print('SOCSure: open http://127.0.0.1:8000 — Ctrl+C to stop')
uvicorn.run('backend.main:app',host='127.0.0.1',port=8000)
