# SOCSure

Offline supervisory analytics prototype for **SIH 2026 · SIH26157**.

SOCSure converts submitted SOC evidence into explainable review leads. It is **not a SIEM, attack detector or autonomous assessor**. All supplied organizations, analysts and records are fictional.

## Start locally

Use Python 3.12. The ZIP includes an already-built React frontend, so Node.js is not needed to run it.

```bash
cd socsure
python -m venv .venv
```

Activate the environment:

- macOS/Linux: `source .venv/bin/activate`
- Windows PowerShell: `.venv\Scripts\Activate.ps1`

Install dependencies once while connected:

```bash
python -m pip install -r requirements.txt
```

Then, including without internet, start with one command:

```bash
python start.py
```

Open **http://127.0.0.1:8000**. Stop with Ctrl+C. The service binds to loopback by default. No cloud AI, API keys, external fonts, CDN assets or GPU are used. The bundled database contains the analyzed demo; if absent, the demo is created on first access.

For a fully disconnected machine, prepare a wheelhouse on a matching Python/OS/architecture:

```bash
python -m pip download -r requirements.txt -d wheelhouse
# Transfer the project and wheelhouse to the disconnected machine, then:
python -m pip install --no-index --find-links wheelhouse -r requirements.txt
python start.py
```

The ZIP does not contain platform-specific Python dependencies. Install them before disconnecting or transfer a wheelhouse. The first dependency install or Docker build needs connectivity unless dependencies/images are cached.

## Docker

```bash
docker compose up --build
```

Open the same local URL. SQLite is stored in the named `socsure-data` volume. Subsequent startup can run disconnected with the built image available: `docker compose up --no-build`. Docker configuration is supplied; Docker execution was not verified in the authoring environment.

## Demo walkthrough

1. **Overview** opens on June 2026, with 7 CSEs and 420 current-period cases.
2. **Data Upload → Load demo dataset** restores the deterministic synthetic evidence. Earlier decision events are retained; reloading the identical dataset does not erase reviews.
3. **Evidence Quality** shows required-field completeness, duplicates, timestamp issues, broken relationships and missing investigations. The clean demo passes the submission checks.
4. **CSE Overview → Northern Grid**: escalation for High/Critical cases falls from a 50% historical median to 6.7%. The baseline table shows history and the selected peers.
5. **Findings**: filter by CSE, severity, type or supervisory confidence. Open **Rules** to change thresholds and create a new analysis run.
6. **Recommended Review**: select a 10/20/50-item budget. Round-robin selection spans finding types and entities; cases are deduplicated.
7. Open a finding to inspect signals, baseline comparisons, numerical features and original source records.
8. Choose **Confirm**, **Dismiss** or **Needs more context**, optionally with notes.
9. **Audit & Validation** records the decision events and exports a complete audit JSON. No automatic retraining occurs.

### Injected scenarios

| Scenario | Where to look in June 2026 |
|---|---|
| Escalation drop | Northern Grid: 2 of 30 severe cases escalated, versus 15 of 30 in each earlier period |
| Repetitive investigation notes | Western Power: 28 cases with near-identical notes on different assets |
| Critical rapid closure with little investigation | Coastal Bank: early cases close in 3 minutes with one action and no escalation |
| Repeated same-asset alerts and rapid closure | National Payments: first 20 alerts target the same asset |
| Batch closures | Metro Telecom: first 18 cases close within 85 seconds |
| Repeated High/Critical-to-Low downgrades | Metro Telecom: 12 severe cases downgraded |
| Critical asset activity collapse | Eastern Network: June activity covers 2 of 30 assets and no critical assets |
| New CSE / no historical baseline | River Utilities: June only, compared to matched peers |

The full dataset has 7 CSEs, 19 entity-period declarations, 210 assets, 1,140 alerts, 1,140 cases, 5,655 actions and 268 escalations.

## Upload format

Use one JSON object with keys `entities`, `assets`, `alerts`, `cases`, `actions`, `escalations`, or upload corresponding CSV files together. Example files are in `data/`. Field headers accept snake_case, camelCase or space-separated names. Aliases include `cse_id`, `cse_name`, `period` and `investigation_actions`.

| Dataset | Fields |
|---|---|
| entities | entity_id, entity_name, sector, reporting_period |
| assets | asset_id, entity_id, asset_type, criticality |
| alerts | alert_id, entity_id, asset_id, timestamp, severity, alert_type |
| cases | case_id, alert_id, entity_id, created_at, closed_at, initial_severity, final_severity, status, disposition, analyst_id |
| actions | action_id, case_id, timestamp, action_type, investigation_note |
| escalations | escalation_id, case_id, timestamp, escalation_level |

Use `YYYY-MM` reporting periods, ISO 8601 timestamps with timezones, and severity values `Low`, `Medium`, `High`, `Critical`. Naive timestamps are interpreted as UTC. Case periods derive from creation timestamps; alert periods derive from alert timestamps. Declare one entity row per reported period. Asset IDs must be unique across CSEs.

Select a logical dataset when uploading a JSON array or a CSV with a nonstandard filename. **Create new submission** replaces all active tables. **Replace selected tables** replaces the supplied nonempty tables and preserves other active tables; it does not append individual rows. An empty table in this mode is ignored. Earlier complete submissions remain in SQLite.

Prototype limits: 10 MB per upload, 50,000 incoming records and 5,000 cases. TF-IDF comparisons are quadratic in case count, computed in bounded blocks. Large operational deployments need batch processing and tighter schema validation.

## Methods and interpretation

- **Evidence gate:** required fields, duplicate primary keys, timestamps (including closure before creation), foreign keys, cross-entity references, reporting declarations and missing case actions. Duplicate rows are counted then deduplicated for analysis. Invalid creation times cannot be profiled. Evidence remains available in the stored source dataset.
- **Confidence:** clean evidence with ≥98% completeness is High; ≥90% completeness with a limited invalid/link count is Medium; otherwise Low. Missing required datasets force Low. Quality is calculated over the entire submission and conservatively applied to all findings, not independently calibrated per entity or period. An empty escalation table is allowed because zero escalation may be real.
- **Feature engineering:** duration, investigation depth (excludes Assign/Close), action count, escalation/reopen counts, severity/downgrades, note similarity, previous same-asset/same-type alerts, closure clusters and entity-period aggregate rates.
- **History:** only earlier submitted periods for the same CSE. First submissions are never assumed normal. Historical medians are observational baselines, not approved operating standards.
- **Peers:** the nearest three contemporaneous CSEs by sector penalty + log asset-count distance + log alert-volume distance + critical-alert-share difference. Behavior under assessment is deliberately not used to choose peers. Small cohorts and sector mismatches require examiner context.
- **Rules:** configurable severe-case escalation/depth checks, closure speed, prior same-asset/same-type alerts, closure clustering, severity downgrades and rapid handling with recorded reopening. Cluster counts include the case itself and cases closed within ± the window. Previous-alert counts use all earlier submitted periods, not a fixed rolling window.
- **Isolation Forest:** 100 trees, fixed seed 26157, 10% contamination, minimum 20 valid cases. Trained on the submitted cohort, including current-period cases; this is exploratory cohort-relative scoring, not a trained historical normality model. Score is negative `score_samples`; larger values mean more unusual. Top-decile cases add an independent signal. Missing numerical duration is filled with zero, so interpret model signals alongside evidence quality. Displayed unusual features use robust cohort-median deviations, not causal or SHAP attributions.
- **Workflow:** timestamp-ordered actions plus escalation/closure events. Rare variants are review leads, not policy violations. Rarity uses all valid submitted cases. Case-reopen evidence is a supplied action, not an inferred previous closure event.
- **Text:** TF-IDF and maximum cosine similarity to a different case on a different asset. This is an unrelated-case proxy; similar legitimate templates may also be flagged. It does not evaluate investigative correctness.
- **Negative space:** low overall/critical asset coverage relative to available history and peers. These are activity proxies, not verified monitoring effectiveness. Asset inventory is treated as stable across periods because the input schema has no inventory snapshot date. Low evidence confidence reduces supervisory confidence and adds an explicit evidence caveat.
- **Fusion:** High supervisory confidence requires at least three detector families and High data confidence; Medium requires at least two families and non-Low data confidence. Everything else is Low. These are transparent heuristics, not statistically calibrated probabilities.
- **Priority:** 100 × (0.20 severity + 0.20 anomaly strength + 0.20 supporting-signal count + 0.10 repetition + 0.10 historical deviation flag + 0.10 peer deviation flag + 0.10 data confidence). Severity is the maximum of case and asset severity, normalized to 0–1; aggregate findings use 0.75. Strength is max(Isolation Forest score, signal count/6 capped at 1). Repetition is (previous alerts + closure-cluster count)/15 capped at 1. Confidence maps High/Medium/Low to 1/0.6/0.2. Priority bands: ≥65 High, ≥40 Medium, otherwise Low.
- **Six dimensions:** highest finding attention within each dimension, with evidence-quality attention inverted from data confidence. Absence of a signal means Low attention, not proven SOC effectiveness.
- **Review sampling:** priority-sorted groups by (finding type, CSE), selected round-robin without repeating cases. The pack may include entity-level findings, so budgets are labelled items. Reviewed findings and baseline-only notices are excluded. Fewer eligible items produce a smaller pack.

Each case has one fused finding with a primary type; additional patterns remain visible as supporting signals. Baseline tables on evidence cards compare entity-period metrics, while exact case values are under Feature values. Low-confidence leads remain available with conservative confidence rather than being presented as conclusions.

## Persistence and audit

`data/socsure.db` stores raw dataset versions, complete analysis snapshots and append-only decisions. A SHA-256 prefix identifies each normalized dataset; every reanalysis has its own run ID and timestamp. Detector thresholds, features, record IDs, scores and baseline values are included in audit exports. Stable finding IDs preserve decisions across reanalysis of identical data. If thresholds materially change the interpretation, reviewers should reassess those retained decisions.

The UI shows the active dataset's audit trail. All historical dataset/analysis rows remain in SQLite; cross-version audit browsing is not included in this prototype. SQLite is appropriate for a single local examiner; there is no login system or multi-user access control. Do not expose the service to a network as a production application.

**Validation:** Precision@K and Recall are explicitly “Not measured.” No ground-truth accuracy is claimed. Review Reduction is the calculated percentage of eligible findings omitted from the current review pack; it is not accuracy or measured analyst time saved.

## Development and checks

React + Vite + Plotly.js frontend, FastAPI + Pandas + scikit-learn backend, SQLite repository. Source is in `frontend/src/` and `backend/`. Workflow-sequence analysis is implemented directly rather than using PM4Py.

To rebuild the frontend, use Node 22.13+:

```bash
cd frontend
npm ci
npm run build
cd ..
python start.py
```

For frontend development, run the backend on port 8000 and `npm run dev` from `frontend/`. Vite proxies `/api` to the backend.

```bash
python -m unittest test_system -v
```

The integration suite uses a disposable database and checks the injected scenarios, historical/peer baselines, diverse review sampling, source-evidence retrieval, append-only decisions, broken evidence, invalid uploads, and CSV/JSON ingestion. The authoring run passed all five integration tests and the production frontend build. Browser visual/interaction QA was unavailable in the authoring environment. Optional WebMCP registration is feature-detected; its runtime validation was likewise unavailable. Core use does not require WebMCP.

The machine-readable API schema is available offline at `/openapi.json`. The default CDN-backed Swagger/ReDoc pages are disabled so the application has no documentation-page network dependency.
